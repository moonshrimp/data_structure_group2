package test;

//註解：儲存一個關鍵字的名稱與重量Store a keyword

public class Keyword {
	public String name;
	public double weight;
	
	public Keyword(String name, double weight){
		this.name = name;
		this.weight = weight;
	}
	
	@Override
	public String toString(){
		return "["+name+","+weight+"]"; // 註解：使用這個method會return [name,weight]
	}
}
