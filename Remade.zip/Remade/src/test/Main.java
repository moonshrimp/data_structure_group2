package test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

public class Main {
	public static void main(String[] args) throws IOException {

		System.out.println("Please input your keyword:");
		Scanner scanner = new Scanner(System.in);
		String userInput = scanner.next(); // ++
		String searchKeyword = userInput + "餐廳" + "官方網站"; // 把餐廳、官方網站加進來，提升找到官網的機率
		GoogleQuery gq = new GoogleQuery(searchKeyword);

		// 程式整體的架構我有先調整過一次，也有把主要的內容全部都整合到GoogleQuery的Class裡面，所以之後應該只需要改GoogleQuery就好
		// 在GoogleQuery裡面我也有另外把僅需要修改參數就ok的地方先集中在一起
		// 如果想要調整看看的話，各位可以照GoogleQuery Class的第56行附近的註解來修改code的參數，看看哪樣子會比較適合
		// 另外在第80行下面的部分，是目前先寫起來、預留給之後串接前後端的部分用的code！
		gq.query();

//		gq.titleUrlScore //之後可以拿來sort/串接

		scanner.close();
	}
}