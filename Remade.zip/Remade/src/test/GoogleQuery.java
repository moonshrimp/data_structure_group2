package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class GoogleQuery {
	public String searchKeyword;
	public String url;
	public String content;
	public ArrayList<TitleUrlScore> titleUrlScore = new ArrayList<TitleUrlScore>(); // 把資料存到這裡

	public GoogleQuery(String searchKeyword) {
		this.searchKeyword = searchKeyword;
		this.url = "http://www.google.com/search?q=" + searchKeyword + "&oe=utf8&num=20";

	}

	private String fetchContent() throws IOException {
		String retVal = "";
		URL u = new URL(url);
		URLConnection conn = u.openConnection();
		// set HTTP header
		conn.setRequestProperty("User-agent", "Chrome/107.0.5304.107");
		InputStream in = conn.getInputStream();
		InputStreamReader inReader = new InputStreamReader(in, "utf-8");
		BufferedReader bufReader = new BufferedReader(inReader);
		String line = null;
		while ((line = bufReader.readLine()) != null) {
			retVal += line;
		}
		return retVal;
	}

	public void query() throws IOException {
		if (content == null) {
			content = fetchContent();
		}
		// using Jsoup analyze html string
		Document doc = Jsoup.parse(content);
		// select particular element(tag) which you want
		Elements lis = doc.select("div");
		lis = lis.select(".kCrYT");

		// 這裡可以修改關鍵字與權重計算，目前我只有先簡單地放一個("料理",50）進去
		// 再看看大家覺得要往哪個方向調整參數名稱/權重，出來的內容才會比較貼近「中式料理」的主題
		ArrayList<Keyword> keywords = new ArrayList<Keyword>();
		String name = "料理"; // 關鍵字的字串
		double weight = 50; // 關鍵字的權重
		Keyword k = new Keyword(name, weight);
		keywords.add(k);

//		String [] foodList = {"港式","中式","粵式","台式","山東","重慶","川渝","川菜","台菜"};

		// 資料處理部分
		for (Element li : lis) {
			try {
				String citeUrl = li.select("a").get(0).attr("href");
				String title = li.select("a").get(0).select(".vvjwJb").text();
				String properUrl = citeUrl.substring(citeUrl.indexOf("http"), citeUrl.indexOf("&sa")); // ++
				double score;
				WebPage rootPage = new WebPage(properUrl, title);
				WebTree tree = new WebTree(rootPage);
				if (title.equals("")) {
					continue;
				}
				tree.setPostOrderScore(keywords);
				score = tree.getScore(tree.root);

				// 目前是直接在console把內容印出來，但前後端串連的時候資料通常不會直接用印的（可以用第86行來串）
				System.out.println("餐廳： " + title); // 新的（餐廳）
				System.out.println("網址：" + properUrl); // 新的（餐廳的網址）
				System.out.println("分數：" + score);
				System.out.println();

				// 這裡會先把每一個搜尋結果的「名稱」、「網址」、「分數」都先儲存到TitleUrlScore類別的ArrayList裡面，
				// 之後在前端呈現的內容，應該就會是sort完TitleUrlScore的分數後，再把它們照分數排在前端呈現的網頁裡面
				titleUrlScore.add(new TitleUrlScore(title, properUrl, score)); // 目前的原始資料（還沒排分數）我先把它存至第21行的titleUrlScore那邊～

			} catch (IndexOutOfBoundsException e) {
			}
		}

	}
}