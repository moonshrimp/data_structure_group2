package test;

//註解：Define the relationship between the parent and child nodes
//  	and store the accumulation score calculated by the WebPage
//		定義父節點與子節點的關係，並累積計算一個節點與它的子節點總共有幾分
//		而WebNode本身則是被定義成一個擁有樹狀結構的class

import java.io.IOException;
import java.util.ArrayList;

public class WebNode {
	public WebNode parent;
	public ArrayList<WebNode> children;
	public WebPage webPage;
	public double nodeScore;// This node's score += all its children's nodeScore

	// 註解：建構子(含有一個WebPage)
	public WebNode(WebPage webPage) {
		this.webPage = webPage;
		this.children = new ArrayList<WebNode>();
	}

	// 註解：計算該node自己的分數，並把該分數複製到這個class裡的nodeScore
	// 最後在迴圈中把children裡每個child的分數加總後，便會得出該node最終nodeScore
	public void setNodeScore(ArrayList<Keyword> keywords) throws IOException {
		// this method should be called in post-order mode
		// compute webPage score
		webPage.setScore(keywords);
		// set webPage score to nodeScore
		nodeScore = webPage.score;
		// nodeScore += all children's nodeScore
		for (WebNode child : children) {
			nodeScore += child.nodeScore;
		}
	}

	//新加的
	public double getNodeScore() {
		return this.nodeScore;
	}

	public void addChild(WebNode child) {
		// add the WebNode to its children list
		this.children.add(child);
		child.parent = this; // 被add小孩的WebNode本身，會被assign成參數child的parent

	}

	public boolean isTheLastChild() {
		// parent是一個WebNode，children是一組ArrayList<WebNode>
		if (this.parent == null) // 若沒有父節點，便直接return true
			return true;
		ArrayList<WebNode> siblings = this.parent.children;
		// 若自己是最後的小孩就return true
		return this.equals(siblings.get(siblings.size() - 1));
	}

	public int getDepth() {
		int retVal = 1; // 最上層是1，每往下一層+1
		WebNode currNode = this; // currNode就是這個WebNode
		// 若這個WebNode有父節點，當前節點便會往上提高一層
		while (currNode.parent != null) {
			retVal++;
			currNode = currNode.parent;
		} // 更上層沒有父節點，迴圈就會終止
		return retVal;
	}
}
