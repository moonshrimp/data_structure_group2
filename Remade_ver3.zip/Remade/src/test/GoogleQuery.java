package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class GoogleQuery {
	public String searchKeyword;
	public String url;
	public String content;

	TitleUrlScoreList titleUrlScoreList = new TitleUrlScoreList(); // 後面的Sort會重新排序它裡面的lst

	public GoogleQuery(String searchKeyword) {
		this.searchKeyword = searchKeyword;
		this.url = "http://www.google.com/search?q=" + searchKeyword + "&oe=utf8&num=20";

	}

	private String fetchContent() throws IOException {
		String retVal = "";
		URL u = new URL(url);
		URLConnection conn = u.openConnection();
		// set HTTP header
		conn.setRequestProperty("User-agent", "Chrome/107.0.5304.107");
		InputStream in = conn.getInputStream();
		InputStreamReader inReader = new InputStreamReader(in, "utf-8");
		BufferedReader bufReader = new BufferedReader(inReader);
		String line = null;
		while ((line = bufReader.readLine()) != null) {
			retVal += line;
		}
		return retVal;
	}

	public void query() throws IOException {
		if (content == null) {
			content = fetchContent();
		}
		Document doc = Jsoup.parse(content);
		Elements lis = doc.select("div");
		lis = lis.select(".kCrYT");

		ArrayList<Keyword> keywords = new ArrayList<Keyword>();
//		String name = "料理"; // 關鍵字的字串
//		double weight = 50; // 關鍵字的權重
//		Keyword k = new Keyword(name, weight);
//		keywords.add(k); // 測試版只有先add一個(料理,50)進去

		// 加分區
		keywords.add(new Keyword("集團", 30));
		keywords.add(new Keyword("首頁", 30));
//		keywords.add(new Keyword("Menu",30)); //不能加menu，否則餐廳的Facebook粉絲頁分數都會變得非常高
		keywords.add(new Keyword("關於", 30));
		keywords.add(new Keyword("官方網站", 50));
		keywords.add(new Keyword("官網", 50));
		keywords.add(new Keyword("線上預約", 50));
		keywords.add(new Keyword("線上訂位", 50));

		// 扣分區（部落格、新聞媒體網站常用字），包含這些字會直接扣3萬分，所以有這些字的網站會被排到最底層
		keywords.add(new Keyword("痞客邦", (-30000)));
		keywords.add(new Keyword("Tripadvisor", (-30000)));
		keywords.add(new Keyword("留言", (-30000)));
		keywords.add(new Keyword("食記", (-30000)));
		keywords.add(new Keyword("回訪", (-30000)));
		keywords.add(new Keyword("閱讀更多", (-30000)));
		keywords.add(new Keyword("訂閱", (-30000)));
		keywords.add(new Keyword("新聞", (-30000)));
		keywords.add(new Keyword("作者", (-30000)));
		keywords.add(new Keyword("全台必吃", (-30000))); // 只扣「必吃」的話，會扣到一般餐廳的官網，改成全台會變成複數形，而餐廳的官網不會用複數形去寫自己，所以可以扣
//		keywords.add(new Keyword("熱門", (-30000)));
		keywords.add(new Keyword("熱門店家", (-30000))); // 只扣「熱門」的話，會扣到一般餐廳的官網
		keywords.add(new Keyword("熱門餐廳", (-30000))); // 要改成熱門店家、熱門餐廳這種複數形，因為它們是食記、部落格的常用詞
//		keywords.add(new Keyword("推薦", -30000)); // 不能只扣推薦，否則很多餐廳的官網分數會被扣得很低，要改成下面這種複數形
		keywords.add(new Keyword("美食推薦", (-30000)));
		keywords.add(new Keyword("景點推薦", (-30000)));
		keywords.add(new Keyword("餐廳推薦", (-30000)));
		keywords.add(new Keyword("推薦美食", (-30000)));
		keywords.add(new Keyword("推薦景點", (-30000)));
		keywords.add(new Keyword("推薦餐廳", (-30000)));

		// 部落格最常用的SEO
		keywords.add(new Keyword("2020最新", (-30000)));
		keywords.add(new Keyword("2021最新", (-30000)));
		keywords.add(new Keyword("2022最新", (-30000)));
		keywords.add(new Keyword("2023最新", (-30000)));

		// 資料處理部分
		for (Element li : lis) {
			try {
				String citeUrl = li.select("a").get(0).attr("href");
				String title = li.select("a").get(0).select(".vvjwJb").text();
				String properUrl = citeUrl.substring(citeUrl.indexOf("http"), citeUrl.indexOf("&sa")); // ++
				double score;
				WebPage rootPage = new WebPage(properUrl, title);
				WebTree tree = new WebTree(rootPage);
				if (title.equals("")) {
					continue;
				}
				tree.setPostOrderScore(keywords);
				score = tree.getScore(tree.root);

				// 把沒有排序過的內容印出來測試
//				System.out.println("餐廳： " + title); // 餐廳的名稱
//				System.out.println("網址：" + properUrl); // 餐廳的網址
//				System.out.println("分數：" + score); // 餐廳的分數
//				System.out.println();

				// 在titleUrlScoreList新增每個搜尋到的網站名稱、網址、分數，最後一行就可以直接把它拿來sort
				titleUrlScoreList.add(new TitleUrlScore(title, properUrl, score));

			} catch (IndexOutOfBoundsException e) {
			}
		}
		titleUrlScoreList.sort(); // 用quick sort排出升冪的搜尋結果
		Collections.reverse(titleUrlScoreList.lst); // 把TitleUrlScoreList排列的方式從升冪反轉成降冪

	}
}