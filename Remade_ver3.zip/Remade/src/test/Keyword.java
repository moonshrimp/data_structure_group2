package test;

//註解：儲存一個關鍵字的名稱與重量

public class Keyword {
	public String name;
	public double weight;
	
	public Keyword(String name, double weight){
		this.name = name;
		this.weight = weight;
	}
}
