
public class Testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 打東西測試
		System.out.println("測試");
		System.out.println("測試2");
	}

}
