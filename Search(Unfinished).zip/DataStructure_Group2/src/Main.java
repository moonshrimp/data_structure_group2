import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

public class Main {
	public static void main(String[] args) throws IOException {
		
		System.out.println("Please input (1)num of keywords (2)name and weight:");
		Scanner scanner = new Scanner(System.in);
		
		while(scanner.hasNextLine()){
			int numOfKeywords = scanner.nextInt();
			ArrayList<Keyword> keywords = new ArrayList<Keyword>();
			
			for(int i = 0; i < numOfKeywords; i++)
			{
				String originalName = scanner.next(); //++
				String name = originalName+"餐廳"+"官方網站"; //++把餐廳官方網站加進來
				
				double weight = scanner.nextDouble();
				Keyword k = new Keyword(name, weight);
				keywords.add(k);
				HashMap<String, String> searchName  = new GoogleQuery(keywords,name).query(); //++
				
			}
			//2 烤鴨 5 燒鵝 10
//			tree.setPostOrderScore(keywords); //富錦樹
//			tree.eularPrintTree();
//			tree2.setPostOrderScore(keywords); //銀翼餐廳
//			tree2.eularPrintTree();
		}
		scanner.close();
	}
}