import java.io.IOException;
import java.util.ArrayList;

public class Order {
	public ArrayList<WebTree> webTrees;
	
	public Order() {
		this.webTrees = new ArrayList<>();
	}
	
	public void add(WebTree wt) {
		this.webTrees.add(wt);
	}
	
	public void setPostOrderScore(ArrayList<Keyword> keywords) {
		for (WebTree wt : this.webTrees) {
			try {
				wt.setPostOrderScore(keywords);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	public void printTree() {
		for (WebTree wt : this.webTrees) {
			wt.eularPrintTree();
		}
	}
	
	public void sort() {
		if (webTrees.size() == 0) {
			System.out.println("InvalidOperation");
		} else {
			quickSort(0, webTrees.size() - 1);
		}
	}

	private void quickSort(int leftbound, int rightbound) {
		// 1. Implement QuickSort algorithm
		if (leftbound >= rightbound) {
			return;
		}

		WebTree pivot = webTrees.get(rightbound);
		int j = leftbound;
		int k = rightbound - 1;

		while (j < k) {
			while (true) {
				if (j >= k || webTrees.get(j).root.nodeScore > pivot.root.nodeScore) {
					break;
				}
				j++;
			}

			while (true) {
				if (j >= k || webTrees.get(k).root.nodeScore <= pivot.root.nodeScore) {
					break;
				}
				k--;
			}

			if (j < k) {
				swap(j, k);
			}
		}

		swap(webTrees.indexOf(pivot), j);
		quickSort(leftbound, j - 1);
		quickSort(j + 1, rightbound);
	}

	private void swap(int aIndex, int bIndex) {
		WebTree temp = webTrees.get(aIndex);
		webTrees.set(aIndex, webTrees.get(bIndex));
		webTrees.set(bIndex, temp);
	}
}
