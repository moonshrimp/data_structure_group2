import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

public class Main {
	public static void main(String[] args) throws IOException {
		// root node
		Order order = new Order();
		
		WebPage rootPage1 = new WebPage("http://www.goldenformosa.com.tw/bin/home.php", "金蓬萊");
		WebTree tree = new WebTree(rootPage1);
		tree.root.addChild(new WebNode(new WebPage("http://www.goldenformosa.com.tw/files/13-1250-19780.php", "金蓬萊 菜單")));
		order.add(tree);
		
		WebPage rootPage2 = new WebPage("https://www.ricenshine329.com/", "稻舍 Rice & Shine");
		WebTree tree2 = new WebTree(rootPage2);
		tree2.root.addChild(new WebNode(new WebPage("https://www.ricenshine329.com/menu", "稻舍 菜單")));
		order.add(tree2);
		
		WebPage rootPage3 = new WebPage("https://fujintreegroup.com/brand-%E5%8F%B0%E8%8F%9C/", "富錦樹台菜香檳");
		WebTree tree3 = new WebTree(rootPage3);
		order.add(tree3);
		
		WebPage rootPage4 = new WebPage("http://0225050891.tw.tranews.com/", "儂來餐廳");
		WebTree tree4 = new WebTree(rootPage4);
		order.add(tree4);
		
		WebPage rootPage5 = new WebPage("https://www.mountain-n-seahouse.com/zh-hant/", "山海樓");
		WebTree tree5 = new WebTree(rootPage5);
		order.add(tree5);

		System.out.println("Please input (1)num of keywords (2)name and weight:");
		Scanner scanner = new Scanner(System.in);

		while (scanner.hasNextLine()) {
			int numOfKeywords = scanner.nextInt();
			ArrayList<Keyword> keywords = new ArrayList<Keyword>();

			for (int i = 0; i < numOfKeywords; i++) {
				String name = scanner.next();
				double weight = scanner.nextDouble();
				Keyword k = new Keyword(name, weight);
				keywords.add(k);
			}
			
			
			
			String keyword = keywords.get(0).name;
			for (int i = 1; i < keywords.size(); i++) {
				keyword += keywords.get(i).name;
			}
			
			order.setPostOrderScore(keywords);
			order.sort();
			order.printTree();
			
			System.out.println();
			System.out.println();
			
			GoogleQuery g = new GoogleQuery(keyword);
			System.out.println(g.query());
		}
		scanner.close();
	}

// static {
//  HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() 
//  {
//   public boolean verify(String hostname,SSLSession session) 
//   {
//    return true;
//   }
//  });
// } 
}