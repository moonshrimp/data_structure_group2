import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

public class Main {
	public static void main(String[] args) throws IOException {

		// 各位只需要看Main跟GoogleQuery的中文註解就好，其他Class應該都不用再額外做修改～
		System.out.println("Remade_第三版");
		System.out.println("Please input your keyword:"); // 叫使用者輸入字串

		Scanner scanner = new Scanner(System.in);
		String searchKeyword = scanner.nextLine(); // 讀取使用者輸入的字
		GoogleQuery gq = new GoogleQuery(searchKeyword); // searchKeyword是使用者輸入的字
		gq.query(); // 讓gq使用重新寫過的query()方法，並建立一個依照searchKeyword產生的TitleUrlScoreList

		// 這個迴圈會把所有的搜尋結果依照分數高低，以降冪的方式排出來
		for (int i = 0; i < gq.titleUrlScoreList.lst.size(); i++) {
			System.out.println("第" + (i + 1) + "個搜尋結果"); // 第幾個結果
			System.out.println("網頁名稱：" + gq.titleUrlScoreList.lst.get(i).title); // 網頁名稱
			System.out.println("網址：" + gq.titleUrlScoreList.lst.get(i).url); // 網址
			System.out.println("分數：" + gq.titleUrlScoreList.lst.get(i).score); // 分數
			System.out.println();
		}
		// 因為我把搜尋結果的資料寫成可以直接在Main裡面call出來，
		// 所以之後串接前端時，應該也可以像上面一樣另外寫一個迴圈，或是再用其他方法來call下面這2個元素，
		// 然後把它們放在可以串起來的地方，就能夠顯示到我們設計的網站裡面
//		gq.titleUrlScoreList.lst.get(i).title);
//		gq.titleUrlScoreList.lst.get(i).url);

		scanner.close();
	}
}