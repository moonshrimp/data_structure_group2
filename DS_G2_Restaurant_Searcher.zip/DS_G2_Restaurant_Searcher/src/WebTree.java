//Use postorder traversal to visit the tree 
//(start from the bottom children), 
//and use WebPage to calculate the own score, 
//and the accumulation score will be stored in WebNode. 
//The score of each child node will accumulate to the parent node, 
//until the root node, then use preorder(eular) to print the output.
//註解：用後序走訪的方式（由下至上，由左至右）來執行tree，
//並藉由WebPage這個class計算每一個節點的分數，
//累積的總分會被儲存在WebNode的parent node裡面，
//直到走到root（最上層的父節點）以後，再用前序走訪的方式印出output

import java.io.IOException;
import java.util.ArrayList;

public class WebTree {
	public WebNode root; // root是一個含有WebPage的WebNode

	// 註解：建構子（含有一個放在根結點的WebPage）
	public WebTree(WebPage rootPage) {
		this.root = new WebNode(rootPage); // 註解：這個root（根結點）會被add小孩進去
	}

	public void setPostOrderScore(ArrayList<Keyword> keywords) throws IOException {
		try {
			setPostOrderScore(root, keywords);
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	private void setPostOrderScore(WebNode startNode, ArrayList<Keyword> keywords) throws IOException {
		// 2. compute the score of children nodes via post-order, then setNodeScore for
		// startNode
		// 註解：WebTree call WebNode to count nodeScore
		for (WebNode child : root.children) {
			if (child.getDepth() < root.getDepth()) {
				for (WebNode grandChild : child.children) {
					grandChild.setNodeScore(keywords);
				}
			} else {
				child.setNodeScore(keywords);
			}
		}
		this.root.setNodeScore(keywords);
	}

	// 新加的
	double getScore(WebNode startNode) {
		int nodeDepth = startNode.getDepth();
		return startNode.nodeScore;
	}

	public void eularPrintTree() {
		eularPrintTree(root);
	}

	private void eularPrintTree(WebNode startNode) {
		int nodeDepth = startNode.getDepth();
		if (nodeDepth > 1)
			System.out.print("\n" + repeat("\t", nodeDepth - 1));
		System.out.print("("); // 印出output裡第一個括號
		System.out.print(startNode.webPage.name + "," + startNode.nodeScore); // 印出output的第一行SosLab

		// 3. print child via pre-order
		// 註解：WebNode call WebPage to count score
		System.out.println(); // 空行
		for (WebNode child : startNode.children) {
			boolean tabSwitch = false; // 拿來控制括號的tab開關，預設是關著的
			System.out.print(repeat("\t", child.getDepth() - 1) + "(" + child.webPage.name + "," + child.nodeScore);
			if (child.isTheLastChild() == false) {
				for (WebNode grandchild : child.children) {
					System.out.println("\n" + repeat("\t", grandchild.getDepth() - 1) + "(" + grandchild.webPage.name
							+ "," + grandchild.nodeScore + ")");
					tabSwitch = true; // 需要tab括號，所以把開關打開
				}
			}
			if (tabSwitch == true) {
				System.out.print(repeat("\t", child.getDepth() - 1) + ")\n"); // 開關有打開，再印前面有tab的括號
				tabSwitch = false;
			} else
				System.out.print(")\n"); // 開關沒打開，印普通的括號
		}

		System.out.print(")");// 印出output裡最後一個括號
		if (startNode.isTheLastChild())
			System.out.print("\n" + repeat("\t", nodeDepth - 2));
	}


	private String repeat(String str, int repeat) {
		String retVal = "";
		for (int i = 0; i < repeat; i++) {
			retVal += str;
		}
		return retVal;
	}
}