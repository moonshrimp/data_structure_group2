import java.util.ArrayList;

public class TitleUrlScoreList {
	public ArrayList<TitleUrlScore> lst;

	public TitleUrlScoreList() {
		this.lst = new ArrayList<TitleUrlScore>();
	}

	public void add(TitleUrlScore titleUrlScore) {
		lst.add(titleUrlScore);
	}

	// Quick sort
	public void sort() {
		if (lst.size() == 0) {
			System.out.println("InvalidOperation");
		} else {
			quickSort(0, lst.size() - 1);
		}
	}

	private void quickSort(int leftbound, int rightbound) {
		// 1. Implement QuickSort algorithm
		// Quick sort的演算法(參數：左邊的範圍、右邊的範圍)
		if (leftbound < rightbound) { 
			int i = leftbound;
			int j = rightbound + 1;
			while (true) {
				while (i + 1 < lst.size() && lst.get(++i).score < lst.get(leftbound).score)
					;
				while (j - 1 >= 0 && lst.get(--j).score > lst.get(leftbound).score)
					;
				if (i >= j) {
					break;
				}
				swap(i, j);
			}
			swap(leftbound, j);
			quickSort(leftbound, j - 1);
			quickSort(j + 1, rightbound);
		}
	}

	private void swap(int aIndex, int bIndex) {
		TitleUrlScore temp = lst.get(aIndex);
		lst.set(aIndex, lst.get(bIndex));
		lst.set(bIndex, temp);
	}

//	public void output() {
//		StringBuilder sb = new StringBuilder();
//
//		for (int i = 0; i < lst.size(); i++) {
//			TitleUrlScore k = lst.get(i);
//			if (i > 0)
//				sb.append(" ");
//			sb.append(k.toString());
//		}
//
//		System.out.println(sb.toString());
//	}
//	
	
}
