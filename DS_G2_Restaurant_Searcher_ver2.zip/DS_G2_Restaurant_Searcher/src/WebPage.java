import java.io.IOException;
import java.util.ArrayList;

public class WebPage {
	public String url;
	public String name;
	public WordCounter counter;
	public double score;

	//註解：建構子(含有一個連結、一個名字)	
	public WebPage(String url, String name) {
		this.url = url;
		this.name = name;
		this.counter = new WordCounter(url);
	}

	// 註解：每個keyword都擁有(String name, double weight)的attribute
	public void setScore(ArrayList<Keyword> keywords) throws IOException {
		score = 0;
		for (int i = 0; i < keywords.size(); i++) {
			String k = keywords.get(i).name;
			double weight = keywords.get(i).weight;
			score += counter.countKeyword(k) * weight;
		}

	}

}