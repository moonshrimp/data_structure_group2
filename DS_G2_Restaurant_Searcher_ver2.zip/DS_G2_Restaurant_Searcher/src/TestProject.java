

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestProject
 */
@WebServlet("/TestProject")
public class TestProject extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestProject() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		if(request.getParameter("keyword")== null) {
			String requestUri = request.getRequestURI();
			request.setAttribute("requestUri", requestUri);
			request.getRequestDispatcher("Search.jsp").forward(request, response);
			return;
		}
		GoogleQuery gq = new GoogleQuery(request.getParameter("keyword"));
		gq.query();
		ArrayList<TitleUrlScore> resultList = gq.titleUrlScoreList.lst;
		int resultNum = resultList.size();
		String[][] s = new String[resultNum][2];
		request.setAttribute("query", s);
		int num = 0;
		// 這個迴圈會把所有的搜尋結果依照分數高低，以降冪的方式排出來
		for (int i = 0; i < resultNum; i++) {
			String title = resultList.get(i).title;
			String url = resultList.get(i).url;
			String score = Double.toString(resultList.get(i).score);
			System.out.println("第" + (i + 1) + "個搜尋結果"); // 第幾個結果
			System.out.println("網頁名稱：" + title); // 網頁名稱
			System.out.println("網址：" + url); // 網址
			System.out.println("分數：" + score); // 分數
			System.out.println();
			s[i][0] = title;
		    s[i][1] = url;
		}		
		request.getRequestDispatcher("googleitem.jsp").forward(request, response); 
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
