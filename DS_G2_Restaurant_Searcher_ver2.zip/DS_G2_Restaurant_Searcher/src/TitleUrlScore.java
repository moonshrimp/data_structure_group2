
public class TitleUrlScore {

	public String title;
	public String url;
	public double score;
	
	
	public TitleUrlScore(String title,String url,double score) {
		this.title =title;
		this.url=url;
		this.score=score;
	}
	
	
	
	
}
