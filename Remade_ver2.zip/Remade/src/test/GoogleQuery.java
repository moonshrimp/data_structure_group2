package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class GoogleQuery {
	public String searchKeyword;
	public String url;
	public String content;

	TitleUrlScoreList titleUrlScoreList = new TitleUrlScoreList(); // 後面的Sort會重新排序它裡面的lst

	public GoogleQuery(String searchKeyword) {
		this.searchKeyword = searchKeyword;
		this.url = "http://www.google.com/search?q=" + searchKeyword + "&oe=utf8&num=20";

	}

	private String fetchContent() throws IOException {
		String retVal = "";
		URL u = new URL(url);
		URLConnection conn = u.openConnection();
		// set HTTP header
		conn.setRequestProperty("User-agent", "Chrome/107.0.5304.107");
		InputStream in = conn.getInputStream();
		InputStreamReader inReader = new InputStreamReader(in, "utf-8");
		BufferedReader bufReader = new BufferedReader(inReader);
		String line = null;
		while ((line = bufReader.readLine()) != null) {
			retVal += line;
		}
		return retVal;
	}

	public void query() throws IOException {
		if (content == null) {
			content = fetchContent();
		}
		Document doc = Jsoup.parse(content);
		Elements lis = doc.select("div");
		lis = lis.select(".kCrYT");

		// 各位只需要在這邊修改關鍵字與權重計算的參數就好
		// 像是如果覺得網頁裡有「烤鴨」這個關鍵字就可以多拿100分
		// 就可以add(new Keyword("烤鴨",100))
		// 目前我只有先簡單地放一個("料理",50）進去
		// 再看看大家覺得要往哪個方向調整關鍵字/權重，加出來的分數才比較能找到「中式料理」的餐廳網站
		ArrayList<Keyword> keywords = new ArrayList<Keyword>();
		String name = "料理"; // 關鍵字的字串
		double weight = 50; // 關鍵字的權重
		Keyword k = new Keyword(name, weight);
		keywords.add(k); // 目前只有add一個(料理,50)進去

		// 可以新增的關鍵字例子（或是要加其他的也都ok）
//		"港式","中式","粵式","台式","山東","重慶","川渝","川菜","台菜"

		// 資料處理部分
		for (Element li : lis) {
			try {
				String citeUrl = li.select("a").get(0).attr("href");
				String title = li.select("a").get(0).select(".vvjwJb").text();
				String properUrl = citeUrl.substring(citeUrl.indexOf("http"), citeUrl.indexOf("&sa")); // ++
				double score;
				WebPage rootPage = new WebPage(properUrl, title);
				WebTree tree = new WebTree(rootPage);
				if (title.equals("")) {
					continue;
				}
				tree.setPostOrderScore(keywords);
				score = tree.getScore(tree.root);

				// 把沒有排序過的內容印出來測試
//				System.out.println("餐廳： " + title); // 餐廳的名稱
//				System.out.println("網址：" + properUrl); // 餐廳的網址
//				System.out.println("分數：" + score); // 餐廳的分數
//				System.out.println();

				// 在titleUrlScoreList新增每個搜尋到的網站名稱、網址、分數，下面就可以直接拿來sort
				titleUrlScoreList.add(new TitleUrlScore(title, properUrl, score));

			} catch (IndexOutOfBoundsException e) {
			}
		}
		titleUrlScoreList.sort(); // 用quick sort排出升冪的搜尋結果

	}
}